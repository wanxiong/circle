
config = {
    basePath: __dirname
}

module.exports = config;
